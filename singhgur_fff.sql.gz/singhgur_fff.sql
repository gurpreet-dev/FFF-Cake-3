-- MySQL dump 10.13  Distrib 5.6.38, for Linux (x86_64)
--
-- Host: localhost    Database: singhgur_fff
-- ------------------------------------------------------
-- Server version	5.6.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `county` varchar(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` (`id`, `county`) VALUES (4,'Adair '),(5,'Guthrie'),(6,'Adams'),(7,'Adams '),(8,'Taylor'),(9,'Allamakee'),(10,'Allamakee '),(11,'Clayton'),(12,'Appanoose'),(13,'Appanoose '),(14,'Monroe'),(15,'Audubon'),(16,'Benton'),(17,'Benton '),(18,'Linn'),(19,'Black Hawk'),(20,'Black Hawk '),(21,'Bremer'),(22,'Black Hawk '),(23,'Buchanan'),(24,'Boone'),(25,'Boone '),(26,'Dallas'),(27,'Boone '),(28,'Polk '),(29,'Story'),(30,'Bremer'),(31,'Bremer '),(32,'Fayette'),(33,'Buchanan'),(34,'Buchanan '),(35,'Fayette'),(36,'Buena Vista'),(37,'Butler'),(38,'Butler '),(39,'Floyd'),(40,'Calhoun'),(41,'Calhoun '),(42,'Sac'),(43,'Calhoun '),(44,'Webster'),(45,'Carroll'),(46,'Carroll '),(47,'Greene'),(48,'Carroll '),(49,'Guthrie'),(50,'Cass'),(51,'Cedar'),(52,'Cedar '),(53,'Johnson'),(54,'Cedar '),(55,'Muscatine'),(56,'Cedar '),(57,'Muscatine '),(58,'Scott'),(59,'Cerro Gordo'),(60,'Cerro Gordo '),(61,'Floyd'),(62,'Cherokee'),(63,'Chickasaw'),(64,'Chickasaw '),(65,'Floyd'),(66,'Chickasaw '),(67,'Howard'),(68,'Clarke'),(69,'Clay'),(70,'Clayton'),(71,'Clayton '),(72,'Delaware'),(73,'Clinton'),(74,'Clinton '),(75,'Jackson'),(76,'Crawford'),(77,'Crawford '),(78,'Harrison'),(79,'Dallas'),(80,'Dallas '),(81,'Madison '),(82,'Polk '),(83,'War...'),(84,'Dallas '),(85,'Polk'),(86,'Davis'),(87,'Decatur'),(88,'Delaware'),(89,'Delaware '),(90,'Dubuque'),(91,'Des Moines'),(92,'Dickinson'),(93,'Dubuque'),(94,'Dubuque '),(95,'Jackson'),(96,'Dubuque '),(97,'Jones'),(98,'Emmet'),(99,'Fayette'),(100,'Floyd'),(101,'Franklin'),(102,'Franklin '),(103,'Hardin'),(104,'Franklin '),(105,'Wright'),(106,'Fremont'),(107,'Fremont '),(108,'Mills'),(109,'Fremont '),(110,'Page'),(111,'Greene'),(112,'Grundy'),(113,'Guthrie'),(114,'Hamilton'),(115,'Hamilton '),(116,'Webster'),(117,'Hancock'),(118,'Hancock '),(119,'Winnebago'),(120,'Hardin'),(121,'Harrison'),(122,'Henry'),(123,'Henry '),(124,'Jefferson '),(125,'Washington Count...'),(126,'Howard'),(127,'Howard '),(128,'Mitchell'),(129,'Humboldt'),(130,'Humboldt '),(131,'Kossuth'),(132,'Humboldt '),(133,'Pocahontas'),(134,'Ida'),(135,'Iowa'),(136,'Iowa '),(137,'Keokuk'),(138,'Iowa '),(139,'Poweshiek'),(140,'Jackson'),(141,'Jasper'),(142,'Jasper '),(143,'Polk'),(144,'Jefferson'),(145,'Johnson'),(146,'Jones'),(147,'Keokuk'),(148,'Keokuk '),(149,'Washington'),(150,'Kossuth'),(151,'Kossuth '),(152,'Palo Alto'),(153,' '),(154,'Lee'),(155,'Linn'),(156,'Louisa'),(157,'Lucas'),(158,'Lyon'),(159,'Madison'),(160,'Madison '),(161,'Warren'),(162,'Mahaska'),(163,'Mahaska '),(164,'Marion'),(165,'Mahaska '),(166,'Monroe '),(167,'Wapello'),(168,'Mahaska '),(169,'Poweshiek'),(170,'Marion'),(171,'Marshall'),(172,'Marshall '),(173,'Tama'),(174,'Mills'),(175,'Mitchell'),(176,'Monona'),(177,'Monroe'),(178,'Montgomery'),(179,'Muscatine'),(180,'Muscatine '),(181,'Scott'),(182,'O Brien'),(183,'O Brien '),(184,'Sioux'),(185,'Osceola'),(186,'Page'),(187,'Palo Alto'),(188,'Plymouth'),(189,'Plymouth '),(190,'Woodbury'),(191,'Pocahontas'),(192,'Polk'),(193,'Polk '),(194,'Warren'),(195,'Pottawattamie'),(196,'Pottawattamie '),(197,'Shelby'),(198,'Poweshiek'),(199,'Ringgold'),(200,'Ringgold '),(201,'Taylor'),(202,'Ringgold '),(203,'Union'),(204,'Sac'),(205,'Scott'),(206,'Shelby'),(207,'Sioux'),(208,'Story'),(209,'Tama'),(210,'Taylor'),(211,'Union'),(212,'Van Buren'),(213,'Wapello'),(214,'Warren'),(215,'Washington'),(216,'Wayne'),(217,'Webster'),(218,'Winnebago'),(219,'Winneshiek'),(220,'Woodbury'),(221,'Worth'),(222,'Wright');
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(355) DEFAULT NULL,
  `email` varchar(355) DEFAULT NULL,
  `message` text,
  `reply` text,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` (`id`, `name`, `email`, `message`, `reply`, `created`, `modified`) VALUES (2,'Gurpreet singh','gurpreet@avainfotech.com','wqdrwqrqwetewq','hello','2018-03-27 07:08:05','2018-03-27 07:20:05'),(3,'PRATEEK','prateek@avainfotech.com','GGHFHGFHGGHJFGHGHGYUG@@@***@@(@(@)@)@)///**//*/*-','jhgfdefdf','2018-03-27 09:35:57','2018-03-29 04:13:26'),(4,'prateek787899','shar@jhjkhjh','dsad','hfhfhfrh','2018-03-27 09:42:31','2018-04-04 07:13:04'),(5,'prateek787899','shar@jhjkhjh','dsad','hhhjjj','2018-03-27 09:43:49','2018-04-04 05:19:47'),(6,'wddsdsdssssss','hjhhhhhh@ggggg','jlkhlklhlhlh',NULL,'2018-03-27 12:24:53','2018-03-27 12:24:53'),(7,'prateek','hjhjhj@jhjhjh.com','1311354656465','yo','2018-03-30 05:22:30','2018-04-03 07:05:02'),(8,'prateek','hjhjhj@jhjhjh.com','1311354656465','ghtgggg','2018-03-30 05:29:13','2018-04-03 13:09:33'),(9,'prateek ','prateek@avainfotech.com','8585858585','858585','2018-04-04 07:14:56','2018-04-04 07:15:27'),(10,'prateek ','prateek@avainfotech.com','8585858585',NULL,'2018-04-04 08:32:00','2018-04-04 08:32:00'),(11,'prateee','prateek@avainfotech.com','56856556','eatgwesygweywreyr','2018-04-10 07:11:32','2018-04-10 11:05:58'),(12,'prateek','prateek@avainfotech.com','hkjhjghgh','558585','2018-04-11 04:06:31','2018-04-11 04:13:01'),(13,'prateek ','prateek@avainfotech.com','ghghghghgh','yo','2018-04-11 04:07:52','2018-04-11 04:11:46');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `iso_code_2` varchar(2) NOT NULL,
  `iso_code_3` varchar(3) NOT NULL,
  `address_format` text NOT NULL,
  `postcode_required` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM AUTO_INCREMENT=258 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` (`country_id`, `name`, `iso_code_2`, `iso_code_3`, `address_format`, `postcode_required`, `status`) VALUES (1,'Afghanistan','AF','AFG','',0,1),(2,'Albania','AL','ALB','',0,1),(3,'Algeria','DZ','DZA','',0,1),(4,'American Samoa','AS','ASM','',0,1),(5,'Andorra','AD','AND','',0,1),(6,'Angola','AO','AGO','',0,1),(7,'Anguilla','AI','AIA','',0,1),(8,'Antarctica','AQ','ATA','',0,1),(9,'Antigua and Barbuda','AG','ATG','',0,1),(10,'Argentina','AR','ARG','',0,1),(11,'Armenia','AM','ARM','',0,1),(12,'Aruba','AW','ABW','',0,1),(13,'Australia','AU','AUS','',0,1),(14,'Austria','AT','AUT','',0,1),(15,'Azerbaijan','AZ','AZE','',0,1),(16,'Bahamas','BS','BHS','',0,1),(17,'Bahrain','BH','BHR','',0,1),(18,'Bangladesh','BD','BGD','',0,1),(19,'Barbados','BB','BRB','',0,1),(20,'Belarus','BY','BLR','',0,1),(21,'Belgium','BE','BEL','{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{postcode} {city}\r\n{country}',0,1),(22,'Belize','BZ','BLZ','',0,1),(23,'Benin','BJ','BEN','',0,1),(24,'Bermuda','BM','BMU','',0,1),(25,'Bhutan','BT','BTN','',0,1),(26,'Bolivia','BO','BOL','',0,1),(27,'Bosnia and Herzegovina','BA','BIH','',0,1),(28,'Botswana','BW','BWA','',0,1),(29,'Bouvet Island','BV','BVT','',0,1),(30,'Brazil','BR','BRA','',0,1),(31,'British Indian Ocean Territory','IO','IOT','',0,1),(32,'Brunei Darussalam','BN','BRN','',0,1),(33,'Bulgaria','BG','BGR','',0,1),(34,'Burkina Faso','BF','BFA','',0,1),(35,'Burundi','BI','BDI','',0,1),(36,'Cambodia','KH','KHM','',0,1),(37,'Cameroon','CM','CMR','',0,1),(38,'Canada','CA','CAN','',0,1),(39,'Cape Verde','CV','CPV','',0,1),(40,'Cayman Islands','KY','CYM','',0,1),(41,'Central African Republic','CF','CAF','',0,1),(42,'Chad','TD','TCD','',0,1),(43,'Chile','CL','CHL','',0,1),(44,'China','CN','CHN','',0,1),(45,'Christmas Island','CX','CXR','',0,1),(46,'Cocos (Keeling) Islands','CC','CCK','',0,1),(47,'Colombia','CO','COL','',0,1),(48,'Comoros','KM','COM','',0,1),(49,'Congo','CG','COG','',0,1),(50,'Cook Islands','CK','COK','',0,1),(51,'Costa Rica','CR','CRI','',0,1),(52,'Cote D\'Ivoire','CI','CIV','',0,1),(53,'Croatia','HR','HRV','',0,1),(54,'Cuba','CU','CUB','',0,1),(55,'Cyprus','CY','CYP','',0,1),(56,'Czech Republic','CZ','CZE','',0,1),(57,'Denmark','DK','DNK','',0,1),(58,'Djibouti','DJ','DJI','',0,1),(59,'Dominica','DM','DMA','',0,1),(60,'Dominican Republic','DO','DOM','',0,1),(61,'East Timor','TL','TLS','',0,1),(62,'Ecuador','EC','ECU','',0,1),(63,'Egypt','EG','EGY','',0,1),(64,'El Salvador','SV','SLV','',0,1),(65,'Equatorial Guinea','GQ','GNQ','',0,1),(66,'Eritrea','ER','ERI','',0,1),(67,'Estonia','EE','EST','',0,1),(68,'Ethiopia','ET','ETH','',0,1),(69,'Falkland Islands (Malvinas)','FK','FLK','',0,1),(70,'Faroe Islands','FO','FRO','',0,1),(71,'Fiji','FJ','FJI','',0,1),(72,'Finland','FI','FIN','',0,1),(74,'France, Metropolitan','FR','FRA','{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{postcode} {city}\r\n{country}',1,1),(75,'French Guiana','GF','GUF','',0,1),(76,'French Polynesia','PF','PYF','',0,1),(77,'French Southern Territories','TF','ATF','',0,1),(78,'Gabon','GA','GAB','',0,1),(79,'Gambia','GM','GMB','',0,1),(80,'Georgia','GE','GEO','',0,1),(81,'Germany','DE','DEU','{company}\r\n{firstname} {lastname}\r\n{address_1}\r\n{address_2}\r\n{postcode} {city}\r\n{country}',1,1),(82,'Ghana','GH','GHA','',0,1),(83,'Gibraltar','GI','GIB','',0,1),(84,'Greece','GR','GRC','',0,1),(85,'Greenland','GL','GRL','',0,1),(86,'Grenada','GD','GRD','',0,1),(87,'Guadeloupe','GP','GLP','',0,1),(88,'Guam','GU','GUM','',0,1),(89,'Guatemala','GT','GTM','',0,1),(90,'Guinea','GN','GIN','',0,1),(91,'Guinea-Bissau','GW','GNB','',0,1),(92,'Guyana','GY','GUY','',0,1),(93,'Haiti','HT','HTI','',0,1),(94,'Heard and Mc Donald Islands','HM','HMD','',0,1),(95,'Honduras','HN','HND','',0,1),(96,'Hong Kong','HK','HKG','',0,1),(97,'Hungary','HU','HUN','',0,1),(98,'Iceland','IS','ISL','',0,1),(99,'India','IN','IND','',0,1),(100,'Indonesia','ID','IDN','',0,1),(101,'Iran (Islamic Republic of)','IR','IRN','',0,1),(102,'Iraq','IQ','IRQ','',0,1),(103,'Ireland','IE','IRL','',0,1),(104,'Israel','IL','ISR','',0,1),(105,'Italy','IT','ITA','',0,1),(106,'Jamaica','JM','JAM','',0,1),(107,'Japan','JP','JPN','',0,1),(108,'Jordan','JO','JOR','',0,1),(109,'Kazakhstan','KZ','KAZ','',0,1),(110,'Kenya','KE','KEN','',0,1),(111,'Kiribati','KI','KIR','',0,1),(112,'North Korea','KP','PRK','',0,1),(113,'South Korea','KR','KOR','',0,1),(114,'Kuwait','KW','KWT','',0,1),(115,'Kyrgyzstan','KG','KGZ','',0,1),(116,'Lao People\'s Democratic Republic','LA','LAO','',0,1),(117,'Latvia','LV','LVA','',0,1),(118,'Lebanon','LB','LBN','',0,1),(119,'Lesotho','LS','LSO','',0,1),(120,'Liberia','LR','LBR','',0,1),(121,'Libyan Arab Jamahiriya','LY','LBY','',0,1),(122,'Liechtenstein','LI','LIE','',0,1),(123,'Lithuania','LT','LTU','',0,1),(124,'Luxembourg','LU','LUX','',0,1),(125,'Macau','MO','MAC','',0,1),(126,'FYROM','MK','MKD','',0,1),(127,'Madagascar','MG','MDG','',0,1),(128,'Malawi','MW','MWI','',0,1),(129,'Malaysia','MY','MYS','',0,1),(130,'Maldives','MV','MDV','',0,1),(131,'Mali','ML','MLI','',0,1),(132,'Malta','MT','MLT','',0,1),(133,'Marshall Islands','MH','MHL','',0,1),(134,'Martinique','MQ','MTQ','',0,1),(135,'Mauritania','MR','MRT','',0,1),(136,'Mauritius','MU','MUS','',0,1),(137,'Mayotte','YT','MYT','',0,1),(138,'Mexico','MX','MEX','',0,1),(139,'Micronesia, Federated States of','FM','FSM','',0,1),(140,'Moldova, Republic of','MD','MDA','',0,1),(141,'Monaco','MC','MCO','',0,1),(142,'Mongolia','MN','MNG','',0,1),(143,'Montserrat','MS','MSR','',0,1),(144,'Morocco','MA','MAR','',0,1),(145,'Mozambique','MZ','MOZ','',0,1),(146,'Myanmar','MM','MMR','',0,1),(147,'Namibia','NA','NAM','',0,1),(148,'Nauru','NR','NRU','',0,1),(149,'Nepal','NP','NPL','',0,1),(150,'Netherlands','NL','NLD','',0,1),(151,'Netherlands Antilles','AN','ANT','',0,1),(152,'New Caledonia','NC','NCL','',0,1),(153,'New Zealand','NZ','NZL','',0,1),(154,'Nicaragua','NI','NIC','',0,1),(155,'Niger','NE','NER','',0,1),(156,'Nigeria','NG','NGA','',0,1),(157,'Niue','NU','NIU','',0,1),(158,'Norfolk Island','NF','NFK','',0,1),(159,'Northern Mariana Islands','MP','MNP','',0,1),(160,'Norway','NO','NOR','',0,1),(161,'Oman','OM','OMN','',0,1),(162,'Pakistan','PK','PAK','',0,1),(163,'Palau','PW','PLW','',0,1),(164,'Panama','PA','PAN','',0,1),(165,'Papua New Guinea','PG','PNG','',0,1),(166,'Paraguay','PY','PRY','',0,1),(167,'Peru','PE','PER','',0,1),(168,'Philippines','PH','PHL','',0,1),(169,'Pitcairn','PN','PCN','',0,1),(170,'Poland','PL','POL','',0,1),(171,'Portugal','PT','PRT','',0,1),(172,'Puerto Rico','PR','PRI','',0,1),(173,'Qatar','QA','QAT','',0,1),(174,'Reunion','RE','REU','',0,1),(175,'Romania','RO','ROM','',0,1),(176,'Russian Federation','RU','RUS','',0,1),(177,'Rwanda','RW','RWA','',0,1),(178,'Saint Kitts and Nevis','KN','KNA','',0,1),(179,'Saint Lucia','LC','LCA','',0,1),(180,'Saint Vincent and the Grenadines','VC','VCT','',0,1),(181,'Samoa','WS','WSM','',0,1),(182,'San Marino','SM','SMR','',0,1),(183,'Sao Tome and Principe','ST','STP','',0,1),(184,'Saudi Arabia','SA','SAU','',0,1),(185,'Senegal','SN','SEN','',0,1),(186,'Seychelles','SC','SYC','',0,1),(187,'Sierra Leone','SL','SLE','',0,1),(188,'Singapore','SG','SGP','',0,1),(189,'Slovak Republic','SK','SVK','{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{city} {postcode}\r\n{zone}\r\n{country}',0,1),(190,'Slovenia','SI','SVN','',0,1),(191,'Solomon Islands','SB','SLB','',0,1),(192,'Somalia','SO','SOM','',0,1),(193,'South Africa','ZA','ZAF','',0,1),(194,'South Georgia &amp; South Sandwich Islands','GS','SGS','',0,1),(195,'Spain','ES','ESP','',0,1),(196,'Sri Lanka','LK','LKA','',0,1),(197,'St. Helena','SH','SHN','',0,1),(198,'St. Pierre and Miquelon','PM','SPM','',0,1),(199,'Sudan','SD','SDN','',0,1),(200,'Suriname','SR','SUR','',0,1),(201,'Svalbard and Jan Mayen Islands','SJ','SJM','',0,1),(202,'Swaziland','SZ','SWZ','',0,1),(203,'Sweden','SE','SWE','{company}\r\n{firstname} {lastname}\r\n{address_1}\r\n{address_2}\r\n{postcode} {city}\r\n{country}',1,1),(204,'Switzerland','CH','CHE','',0,1),(205,'Syrian Arab Republic','SY','SYR','',0,1),(206,'Taiwan','TW','TWN','',0,1),(207,'Tajikistan','TJ','TJK','',0,1),(208,'Tanzania, United Republic of','TZ','TZA','',0,1),(209,'Thailand','TH','THA','',0,1),(210,'Togo','TG','TGO','',0,1),(211,'Tokelau','TK','TKL','',0,1),(212,'Tonga','TO','TON','',0,1),(213,'Trinidad and Tobago','TT','TTO','',0,1),(214,'Tunisia','TN','TUN','',0,1),(215,'Turkey','TR','TUR','',0,1),(216,'Turkmenistan','TM','TKM','',0,1),(217,'Turks and Caicos Islands','TC','TCA','',0,1),(218,'Tuvalu','TV','TUV','',0,1),(219,'Uganda','UG','UGA','',0,1),(220,'Ukraine','UA','UKR','',0,1),(221,'United Arab Emirates','AE','ARE','',0,1),(222,'United Kingdom','GB','GBR','',1,1),(223,'United States','US','USA','{firstname} {lastname}\r\n{company}\r\n{address_1}\r\n{address_2}\r\n{city}, {zone} {postcode}\r\n{country}',0,1),(224,'United States Minor Outlying Islands','UM','UMI','',0,1),(225,'Uruguay','UY','URY','',0,1),(226,'Uzbekistan','UZ','UZB','',0,1),(227,'Vanuatu','VU','VUT','',0,1),(228,'Vatican City State (Holy See)','VA','VAT','',0,1),(229,'Venezuela','VE','VEN','',0,1),(230,'Viet Nam','VN','VNM','',0,1),(231,'Virgin Islands (British)','VG','VGB','',0,1),(232,'Virgin Islands (U.S.)','VI','VIR','',0,1),(233,'Wallis and Futuna Islands','WF','WLF','',0,1),(234,'Western Sahara','EH','ESH','',0,1),(235,'Yemen','YE','YEM','',0,1),(237,'Democratic Republic of Congo','CD','COD','',0,1),(238,'Zambia','ZM','ZMB','',0,1),(239,'Zimbabwe','ZW','ZWE','',0,1),(242,'Montenegro','ME','MNE','',0,1),(243,'Serbia','RS','SRB','',0,1),(244,'Aaland Islands','AX','ALA','',0,1),(245,'Bonaire, Sint Eustatius and Saba','BQ','BES','',0,1),(246,'Curacao','CW','CUW','',0,1),(247,'Palestinian Territory, Occupied','PS','PSE','',0,1),(248,'South Sudan','SS','SSD','',0,1),(249,'St. Barthelemy','BL','BLM','',0,1),(250,'St. Martin (French part)','MF','MAF','',0,1),(251,'Canary Islands','IC','ICA','',0,1),(252,'Ascension Island (British)','AC','ASC','',0,1),(253,'Kosovo, Republic of','XK','UNK','',0,1),(254,'Isle of Man','IM','IMN','',0,1),(255,'Tristan da Cunha','TA','SHN','',0,1),(256,'Guernsey','GG','GGY','',0,1),(257,'Jersey','JE','JEY','',0,1);
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries`
--

DROP TABLE IF EXISTS `galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `file` varchar(355) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `format` varchar(355) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries`
--

LOCK TABLES `galleries` WRITE;
/*!40000 ALTER TABLE `galleries` DISABLE KEYS */;
INSERT INTO `galleries` (`id`, `user_id`, `file`, `type`, `format`, `created`, `modified`) VALUES (31,72,'1517257263DBBA83F5-AA48-438B-91A0-EAA78A17930A.png','image','image/png','2018-01-29 20:21:03','2018-01-29 20:21:03'),(35,87,'1518974417Jilldearworldpicture05-2016.jpeg','image','image/jpeg','2018-02-18 17:20:17','2018-02-18 17:20:17'),(36,87,'1518974444MEFAT3.jpg','image','image/jpeg','2018-02-18 17:20:45','2018-02-18 17:20:45'),(37,87,'1518974507myactivepicinpine2016.jpg','image','image/jpeg','2018-02-18 17:21:47','2018-02-18 17:21:47'),(38,87,'1518974561Award1.jpg','image','','2018-02-18 17:22:41','2018-02-18 17:22:41'),(39,89,'1520096253213_1519952903174.jpeg','image','image/jpeg','2018-03-03 16:57:33','2018-03-03 16:57:33');
/*!40000 ALTER TABLE `galleries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homesections`
--

DROP TABLE IF EXISTS `homesections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `homesections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(355) DEFAULT NULL,
  `content` text,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homesections`
--

LOCK TABLES `homesections` WRITE;
/*!40000 ALTER TABLE `homesections` DISABLE KEYS */;
INSERT INTO `homesections` (`id`, `title`, `content`, `sort_order`, `created`, `modified`) VALUES (1,'Block 1','<div class=\"section\">\r\n<div class=\"container\">\r\n<div class=\"row\">\r\n<div class=\"col-sm-7 col-lg-push-05 col-xs-12\">\r\n<h3 class=\"h2\">Are you a Personal Trainer?</h3>\r\n<p>Top Local Trainer provide <strong>Personal Trainers in USA</strong>&nbsp;with the tools they need to connect with people looking for their services. Our members take advantage of exclusive features, including enhanced profile visibility on our site, to increase training leads.</p>\r\n<p>Not only that, we&rsquo;ve partnered with some of the best companies in the fitness industry to get you exclusive access to discounts on supplements, educational courses, equipment and a range of the best Personal Training jobs.</p>\r\n<section class=\"trainer-form-container\">\r\n<h5>Improve your knowledge with a course in your area&hellip;</h5>\r\n</section>\r\n</div>\r\n<!-- left col - end -->\r\n<div class=\"col-lg-4 col-lg-push-05 col-sm-5 hidden-xs text-center\">\r\n<div class=\"map map-orange\"><img style=\"width: 100%;\" src=\"images/website/USA-map-blue.svg\" alt=\"\" /></div>\r\n</div>\r\n<!-- right col - end --></div>\r\n</div>\r\n</div>\r\n<hr class=\"home-h-separator\" />',1,'2017-08-18 06:08:40','2017-08-31 09:31:17'),(2,'Block 2','<div class=\"create-profile section\"><img class=\"cp-right-img hidden-xs\" src=\"https://www.toplocaltrainer.co.uk/wp-content/themes/tlt/images/devices-home.png\" alt=\"Create your free profile\" width=\"515\" height=\"465\" />\r\n<div class=\"container\">\r\n<div class=\"row\">\r\n<div class=\"cp-inner col-xs-6 col-lg-push-05 col-xxs-12 center-block-xs\">\r\n<h3 class=\"h2 cp-title text-center-xs\">Create your FREE profile</h3>\r\n<img class=\"cp-content-img img-responsive right-block visible-xs\" src=\"https://www.toplocaltrainer.co.uk/wp-content/themes/tlt/images/devices-home.png\" alt=\"Create your FREE profile\" width=\"515\" height=\"465\" />\r\n<ul class=\"list\">\r\n<li>Create your FREE profile and showcase your expertise to people searching for personal trainers in your area</li>\r\n<li>We funnel location-based &lsquo;personal trainer&rsquo; queries from Google, to our search function, to your profile</li>\r\n<li>Drive extra traffic to your website and boost your social media following (Facebook, Twitter, LinkedIn and more)</li>\r\n<li>Out-muscle your competitors &ndash; the faster you sign up, the more leads you get</li>\r\n<li>Receive ongoing enquiries from local people bitten by the fitness bug &ndash; without lifting a finger</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n</div>',2,'2017-08-18 06:09:55','2017-10-23 22:46:58'),(3,'Block 3','<div class=\"section cta-section orange-bkg white\">\r\n<div class=\"container\">\r\n<div class=\"row\">\r\n<div class=\"col-md-7 col-lg-push-05 col-sm-7 col-xs-12 text-center-xs\">\r\n<h4 class=\"cta-head\">Create your FREE profile now and showcase your skills<br class=\"visible-lg visible-md\" /> to people searching for personal trainers near you</h4>\r\n</div>\r\n<div class=\"col-lg-4 col-lg-push-05 col-sm-5 col-xs-12 text-center\"><a class=\"btn btn-white btn-md\" href=\"users/add\">Create your FREE profile</a></div>\r\n</div>\r\n</div>\r\n</div>',3,'2017-08-18 06:12:25','2017-08-18 07:20:55'),(5,'Block 4','<section class=\"for-searchers grey-bkg\">\r\n<div class=\"section\">\r\n<div class=\"container\">\r\n<div class=\"row\">\r\n<div class=\"col-sm-7 col-lg-push-05 col-xs-12\">\r\n<h3 class=\"h2\">Looking for a Personal Trainer?</h3>\r\n<p>Top Local Trainer is the place to connect with a Personal Trainer in your area. Our network of <strong>expert trainers cover the whole of the USA</strong>, meaning there&rsquo;s at least one, just around the corner from you. Whether you want to get fit, lose weight, or generally improve your wellbeing, we have a fully-qualified trainer that can help. It&rsquo;s free to search, so what are you waiting for?</p>\r\n<section class=\"trainer-form-container\">\r\n<h5>There&rsquo;s an expert fitness trainer waiting near you&hellip;</h5>\r\n<form id=\"sl_search_form\" class=\"home-form\" action=\"trainer\" method=\"get\">\r\n<div class=\"row\">\r\n<div class=\"col-xs-7 col-xxs-12\">\r\n<div class=\"form-group\">\r\n<div class=\"sl-input-box greybg home-input-text\"><input id=\"txtPlaces2\" class=\"sl_post_input greybg form-control\" name=\"search\" type=\"text\" placeholder=\"Enter Location\" /> <input id=\"latitude1\" class=\"form-control\" name=\"latitude\" type=\"hidden\" /> <input id=\"longitude1\" class=\"form-control\" name=\"longitude\" type=\"hidden\" /></div>\r\n</div>\r\n</div>\r\n<div class=\"col-xs-5 col-xxs-12 text-center-xxs\"><input class=\"sl-input-submit home-green-btn-big btn btn-md btn-green\" type=\"submit\" value=\"Find My Trainer\" /></div>\r\n</div>\r\n</form></section>\r\n</div>\r\n<!-- left col - end -->\r\n<div class=\"col-lg-4 col-lg-push-05 col-sm-5 hidden-xs text-center\"><img style=\"width: 100%;\" src=\"images/website/USA-map-blue.svg\" alt=\"\" /></div>\r\n<!-- right col - end --></div>\r\n</div>\r\n</div>\r\n</section>',4,'2017-08-18 06:40:21','2017-08-31 06:51:31'),(6,'Sponsored By','<section class=\"section other-loc dark-grey-bkg white\">\r\n<div class=\"container\">\r\n<h3 class=\"h2 text-center\">Sponsored By</h3>\r\n<div class=\"clearfix\">\r\n<div class=\"col-xs-12\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</section>',0,'2017-09-06 05:43:50','2017-09-06 12:42:08');
/*!40000 ALTER TABLE `homesections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(355) DEFAULT NULL,
  `icon` varchar(355) DEFAULT NULL,
  `link` varchar(355) DEFAULT NULL,
  `background` varchar(355) DEFAULT '#000',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
INSERT INTO `links` (`id`, `name`, `icon`, `link`, `background`, `created`, `modified`) VALUES (3,'Facebook','fa-facebook','https://facebook.com','#3460A1','0000-00-00 00:00:00','2017-08-21 08:25:11'),(4,'Twitter','fa-twitter','https://twitter.com','#28AAE1','0000-00-00 00:00:00','2017-08-21 08:26:08'),(5,'Linkedin','fa-linkedin','https://linkedin.com','#136D9D','0000-00-00 00:00:00','2017-08-21 08:27:29'),(6,'Google Plus','fa-google-plus','https://plus.google.com','#DE5543','0000-00-00 00:00:00','2017-08-21 08:26:34');
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(255) DEFAULT NULL,
  `key` varchar(355) DEFAULT NULL,
  `title` varchar(355) DEFAULT NULL,
  `amazon_order_number` varchar(255) DEFAULT NULL,
  `amazon_tracking_number` varchar(255) DEFAULT NULL,
  `date` varchar(355) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`id`, `user_id`, `key`, `title`, `amazon_order_number`, `amazon_tracking_number`, `date`) VALUES (1,5,'B07BRF2GTW','The Little Gnome','4245454','745675674','11-05-2018'),(2,14,'B07BR7ZPQD','Daizy\'s Monster','reygtdfgrt','herrtzf','12-05-2018'),(3,2,'B07BR7ZPQD','Daizy\'s Monster','hsfdhsfdhsfdhsfdhsfdhsfdhsfdhsfdhsfdhsfdhsfd','xssssssssssssssssssss','12-05-2018'),(4,14,'B07C9CSJ3T','A Trip To The Zoo','12341234','12341234','12-06-2018');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(355) DEFAULT NULL,
  `price` varchar(355) DEFAULT NULL,
  `duration` int(255) DEFAULT NULL,
  `content` text,
  `class` varchar(355) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` (`id`, `title`, `price`, `duration`, `content`, `class`, `created`, `modified`) VALUES (1,'1 Book , 1 Month','35.85',1,'Receive one book for one month.  We’ll pick the best order','bg-danger','0000-00-00 00:00:00','0000-00-00 00:00:00'),(2,'3 Books , 3 Months','60',3,'Receive three books for three months.  We’ll pick the best order','bg-success','0000-00-00 00:00:00','0000-00-00 00:00:00'),(3,'6 Books , 6 Months','120',6,'Receive six books for six months.  We’ll pick the best order','bg-warning','0000-00-00 00:00:00','0000-00-00 00:00:00'),(4,'9 Books , 9 Months','120',9,'Receive nine book for nine months.  We’ll pick the best order','bg-info','0000-00-00 00:00:00','0000-00-00 00:00:00'),(5,'13 Books , 13 Months','150',13,'Receive thirteen books for thirteen months.  We’ll pick the best order','bg-danger','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productkey`
--

DROP TABLE IF EXISTS `productkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productkey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(355) DEFAULT NULL,
  `key` varchar(355) DEFAULT NULL,
  `content` text,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productkey`
--

LOCK TABLES `productkey` WRITE;
/*!40000 ALTER TABLE `productkey` DISABLE KEYS */;
INSERT INTO `productkey` (`id`, `title`, `key`, `content`, `created`) VALUES (1,'Daizy\'s Monster','B07BR7ZPQD','Is that a monster in the backyard? Daizy the lovable dog is on a mission when her imagination gets the best of her. Find out what’s behind the tree...','0000-00-00 00:00:00'),(2,'Myrtle\'s Big Race ','B07BRBNBJ3','Myrtle the Turtle loves to run! But can she win the big race and still have fun? Meet Myrtle and all her friends as they discover something more important than winning.','0000-00-00 00:00:00'),(3,'How To Bake A Monster Cake','B07BRF9VNV','Peter loves to bake, but who is he making that crazy cake for? Come on a fun adventure as Peter and his Mom bake the perfect cake for a special friend!','0000-00-00 00:00:00'),(4,'The Little Gnome','B07BRF2GTW','Would you like to know what it’s like to be a little gnome and live in a tree? Well, open the pages of this fun story to meet a special little gnome and all of his forest friends! ','0000-00-00 00:00:00'),(5,'Preston The Proper Pig','B07BRBXH1K',NULL,'0000-00-00 00:00:00'),(6,'A Trip To The Zoo','B07C9CSJ3T','There is so much to see and do at the zoo! Can you guess what animals they will see? Find out as you join Annie and her baby brother for his first trip to the zoo! ','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `productkey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trainer_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `review` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` (`id`, `trainer_id`, `user_id`, `rating`, `review`, `created`, `modified`) VALUES (9,72,72,5,'He definitely helped changed my life. Lost 40 pounds!','2018-01-29 20:24:10','2018-01-29 20:24:10'),(8,66,66,5,'Kyle helped me lose more weight than I even thought I needed!','2018-01-20 04:55:15','2018-01-20 04:55:15');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staticpages`
--

DROP TABLE IF EXISTS `staticpages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staticpages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(355) DEFAULT NULL,
  `title` varchar(355) DEFAULT NULL,
  `image` varchar(355) DEFAULT NULL,
  `content` text,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staticpages`
--

LOCK TABLES `staticpages` WRITE;
/*!40000 ALTER TABLE `staticpages` DISABLE KEYS */;
INSERT INTO `staticpages` (`id`, `slug`, `title`, `image`, `content`, `created`, `modified`) VALUES (1,'about-us','About us',NULL,'<section class=\"st-read st-company\">\r\n<div class=\"container\">\r\n<div class=\"row\">\r\n<div class=\"col-sm-6\">\r\n<div class=\"read_pic\"><img class=\"custom-image\" src=\"../../../images/website/about1.png\" alt=\"\" /></div>\r\n</div>\r\n<div class=\"col-sm-6\">\r\n<div class=\"read_content\">\r\n<h1 class=\"theme-heading\">about company</h1>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n<h1 class=\"theme-heading black\">what is lorem ipsum?</h1>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n</div>\r\n</div>\r\n<div class=\"col-sm-12\">\r\n<div class=\"read_content\">\r\n<h1 class=\"theme-heading black\">what is lorem ipsum?</h1>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n<!--st-read-end-->','2018-03-27 04:46:18','2018-03-29 13:19:30');
/*!40000 ALTER TABLE `staticpages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(255) DEFAULT NULL,
  `customer` text,
  `transaction_id` varchar(355) DEFAULT NULL,
  `payment_status` varchar(355) DEFAULT NULL,
  `price` varchar(355) DEFAULT NULL,
  `duration` varchar(355) DEFAULT NULL,
  `status` varchar(355) NOT NULL DEFAULT 'ongoing',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` (`id`, `user_id`, `customer`, `transaction_id`, `payment_status`, `price`, `duration`, `status`, `created`, `modified`) VALUES (1,14,'cus_CfJFCWaxGI4mGJ','txn_1CFzwSGASUFwqoPYKJgIb1iP','completed','60','3','ongoing','2018-04-12 07:34:00','2018-04-12 07:34:00'),(2,2,'cus_CfKeWArQbOMuWY','txn_1CFzywGASUFwqoPY4Takg8Hn','completed','120','6','ongoing','2018-04-12 07:36:35','2018-04-12 07:36:35'),(3,14,'cus_CfJFCWaxGI4mGJ','txn_1CG048GASUFwqoPY7tkQbwL8','completed','60','3','ongoing','2018-04-12 07:41:57','2018-04-12 07:41:57'),(4,5,'cus_CfKzibSgOhC6Pz','txn_1CG0J5GASUFwqoPYOGPRVeN0','completed','35.85','1','ongoing','2018-04-12 07:57:23','2018-04-12 07:57:23'),(5,6,'cus_ChF8LHOHw4Zu6w','txn_1CHqdvGASUFwqoPYvbyZRjKW','completed','35.85','1','ongoing','2018-04-17 10:02:31','2018-04-17 10:02:31'),(6,8,'cus_ChaF68ZdjFiZXp','txn_1CIB4bGASUFwqoPYZ9WwUVh2','completed','60','3','ongoing','2018-04-18 07:51:25','2018-04-18 07:51:25');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_county`
--

DROP TABLE IF EXISTS `tbl_county`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_county` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `county` varchar(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_county`
--

LOCK TABLES `tbl_county` WRITE;
/*!40000 ALTER TABLE `tbl_county` DISABLE KEYS */;
INSERT INTO `tbl_county` (`id`, `county`) VALUES (1,'test'),(2,'test2'),(3,'test2'),(4,'Adair '),(5,'Guthrie'),(6,'Adams'),(7,'Adams '),(8,'Taylor'),(9,'Allamakee'),(10,'Allamakee '),(11,'Clayton'),(12,'Appanoose'),(13,'Appanoose '),(14,'Monroe'),(15,'Audubon'),(16,'Benton'),(17,'Benton '),(18,'Linn'),(19,'Black Hawk'),(20,'Black Hawk '),(21,'Bremer'),(22,'Black Hawk '),(23,'Buchanan'),(24,'Boone'),(25,'Boone '),(26,'Dallas'),(27,'Boone '),(28,'Polk '),(29,'Story'),(30,'Bremer'),(31,'Bremer '),(32,'Fayette'),(33,'Buchanan'),(34,'Buchanan '),(35,'Fayette'),(36,'Buena Vista'),(37,'Butler'),(38,'Butler '),(39,'Floyd'),(40,'Calhoun'),(41,'Calhoun '),(42,'Sac'),(43,'Calhoun '),(44,'Webster'),(45,'Carroll'),(46,'Carroll '),(47,'Greene'),(48,'Carroll '),(49,'Guthrie'),(50,'Cass'),(51,'Cedar'),(52,'Cedar '),(53,'Johnson'),(54,'Cedar '),(55,'Muscatine'),(56,'Cedar '),(57,'Muscatine '),(58,'Scott'),(59,'Cerro Gordo'),(60,'Cerro Gordo '),(61,'Floyd'),(62,'Cherokee'),(63,'Chickasaw'),(64,'Chickasaw '),(65,'Floyd'),(66,'Chickasaw '),(67,'Howard'),(68,'Clarke'),(69,'Clay'),(70,'Clayton'),(71,'Clayton '),(72,'Delaware'),(73,'Clinton'),(74,'Clinton '),(75,'Jackson'),(76,'Crawford'),(77,'Crawford '),(78,'Harrison'),(79,'Dallas'),(80,'Dallas '),(81,'Madison '),(82,'Polk '),(83,'War...'),(84,'Dallas '),(85,'Polk'),(86,'Davis'),(87,'Decatur'),(88,'Delaware'),(89,'Delaware '),(90,'Dubuque'),(91,'Des Moines'),(92,'Dickinson'),(93,'Dubuque'),(94,'Dubuque '),(95,'Jackson'),(96,'Dubuque '),(97,'Jones'),(98,'Emmet'),(99,'Fayette'),(100,'Floyd'),(101,'Franklin'),(102,'Franklin '),(103,'Hardin'),(104,'Franklin '),(105,'Wright'),(106,'Fremont'),(107,'Fremont '),(108,'Mills'),(109,'Fremont '),(110,'Page'),(111,'Greene'),(112,'Grundy'),(113,'Guthrie'),(114,'Hamilton'),(115,'Hamilton '),(116,'Webster'),(117,'Hancock'),(118,'Hancock '),(119,'Winnebago'),(120,'Hardin'),(121,'Harrison'),(122,'Henry'),(123,'Henry '),(124,'Jefferson '),(125,'Washington Count...'),(126,'Howard'),(127,'Howard '),(128,'Mitchell'),(129,'Humboldt'),(130,'Humboldt '),(131,'Kossuth'),(132,'Humboldt '),(133,'Pocahontas'),(134,'Ida'),(135,'Iowa'),(136,'Iowa '),(137,'Keokuk'),(138,'Iowa '),(139,'Poweshiek'),(140,'Jackson'),(141,'Jasper'),(142,'Jasper '),(143,'Polk'),(144,'Jefferson'),(145,'Johnson'),(146,'Jones'),(147,'Keokuk'),(148,'Keokuk '),(149,'Washington'),(150,'Kossuth'),(151,'Kossuth '),(152,'Palo Alto'),(153,' '),(154,'Lee'),(155,'Linn'),(156,'Louisa'),(157,'Lucas'),(158,'Lyon'),(159,'Madison'),(160,'Madison '),(161,'Warren'),(162,'Mahaska'),(163,'Mahaska '),(164,'Marion'),(165,'Mahaska '),(166,'Monroe '),(167,'Wapello'),(168,'Mahaska '),(169,'Poweshiek'),(170,'Marion'),(171,'Marshall'),(172,'Marshall '),(173,'Tama'),(174,'Mills'),(175,'Mitchell'),(176,'Monona'),(177,'Monroe'),(178,'Montgomery'),(179,'Muscatine'),(180,'Muscatine '),(181,'Scott'),(182,'O Brien'),(183,'O Brien '),(184,'Sioux'),(185,'Osceola'),(186,'Page'),(187,'Palo Alto'),(188,'Plymouth'),(189,'Plymouth '),(190,'Woodbury'),(191,'Pocahontas'),(192,'Polk'),(193,'Polk '),(194,'Warren'),(195,'Pottawattamie'),(196,'Pottawattamie '),(197,'Shelby'),(198,'Poweshiek'),(199,'Ringgold'),(200,'Ringgold '),(201,'Taylor'),(202,'Ringgold '),(203,'Union'),(204,'Sac'),(205,'Scott'),(206,'Shelby'),(207,'Sioux'),(208,'Story'),(209,'Tama'),(210,'Taylor'),(211,'Union'),(212,'Van Buren'),(213,'Wapello'),(214,'Warren'),(215,'Washington'),(216,'Wayne'),(217,'Webster'),(218,'Winnebago'),(219,'Winneshiek'),(220,'Woodbury'),(221,'Worth'),(222,'Wright');
/*!40000 ALTER TABLE `tbl_county` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(355) DEFAULT NULL,
  `name` varchar(355) DEFAULT NULL,
  `email` varchar(355) DEFAULT NULL,
  `password` varchar(355) DEFAULT NULL,
  `image` varchar(355) DEFAULT NULL,
  `address` text,
  `tokenhash` text,
  `plan_id` int(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `from` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `books_sequence` text,
  `stripe_customer` varchar(355) DEFAULT NULL,
  `subscribed` int(1) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `role`, `name`, `email`, `password`, `image`, `address`, `tokenhash`, `plan_id`, `price`, `duration`, `from`, `to`, `books_sequence`, `stripe_customer`, `subscribed`, `status`, `created`, `modified`) VALUES (1,'admin','Gurpreet Singh','gurpreet@avainfotech.com','$2y$10$HGe0Cww1jS/mgIYG9iPxzuRCktLp.Arx/QUjpuoCbpTR/Nci4h3BS','1522746096Desert.jpg','Plot No. 1095, Lal Bahadur Shastri Road, P&T Staff Colony, Mulund West, Mumbai, Maharashtra, India','bddef1830c9e01c1c463a89cd42a93c6',1,'30','3','29-03-2018','29-06-2018',NULL,NULL,0,1,'2018-03-22 08:37:12','2018-04-04 07:53:58'),(2,'user','Anshul','anshul@avainfotech.com','$2y$10$qtZnBsO77OMbNbzjP.po.ewkrgtqs.h0yvrBpqTiEln74ss6jvAFO','1522326117noimage.png','abc addresss','32d5dde074fda6fc4c41da160b25f887',3,'120','6','12-04-2018','12-10-2018','B07C9CSJ3T,B07BRBXH1K,B07BRF2GTW,B07BRF9VNV,B07BRBNBJ3,B07BR7ZPQD','cus_CfKeWArQbOMuWY',1,1,'2018-03-22 10:10:05','2018-03-29 12:21:57'),(3,'user','gurpreet singh','gurpreet@gmail.com','$2y$10$xMOug3ACcgO307cZBBYkluLlP/l5QIw9LXAuNGY4iCaiKqXA.rpcC',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,0,1,'2018-03-22 15:36:41','2018-03-22 15:36:41'),(4,'user','gurpreet singh','gurpreet77@gmail.com','$2y$10$00rPV72NTwn44dnBucpeW.CGcFWjRA7Q.dV9nzeoivyjDj4u7UxXG',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,0,1,'2018-03-22 15:42:31','2018-03-22 15:42:31'),(5,'user','prateek ','prateek@avainfotech.com','$2y$10$otABcOwBywHphde6I0CAb.ai2SIl9L97TzXzCJIjC3e2iW/CGHGS.','1522387804Chrysanthemum.jpg','hghghhfhgfgh','844498cc75ee95f2d12a5e334ab58c3f',1,'35.85','1','12-04-2018','12-05-2018','B07BRBXH1K','cus_CfKzibSgOhC6Pz',1,1,'2018-03-26 12:12:46','2018-04-03 10:31:34'),(6,'user','kuldeep','kuldeepjha@avainfotech.com','$2y$10$ZXqv/wh3lMJi84/h8oQ6BOrbUYlOfS.qu/Pzc5lxPA3Arjb/GNEi2',NULL,'ghghgh223455hjuhjh',NULL,1,'35.85','1','17-04-2018','17-05-2018','B07C9CSJ3T','cus_ChF8LHOHw4Zu6w',1,1,'2018-03-27 04:07:21','2018-04-03 07:00:42'),(7,'user',' Gurpreet','gurpreet@avainfotech.comm','$2y$10$fXxdCHB4It7WwtrO2qcnNOXEHKG5kIf7oxxp8wh45gTpkG3qy.Xx6',NULL,'dgdsgdsg',NULL,NULL,NULL,NULL,'','',NULL,NULL,0,1,'2018-03-27 09:12:31','2018-04-03 08:53:57'),(8,'user',' netin','netin@avainfotech.com','$2y$10$QE60Ti55Hb5J8byzkavDLuxHXKFGNiThAcz.5d1LBbVSHrt7ejJnK',NULL,'5858',NULL,2,'60','3','18-04-2018','18-07-2018','','cus_ChaF68ZdjFiZXp',1,1,'2018-03-27 09:25:38','2018-04-03 08:53:25'),(9,NULL,'Wojtek','wojtek@grabski.ca','$2y$10$lt3SUAKNOJMxW5Cs7LhSwex3g3tQ48mWCd3sRZ9A9B6eQY/iFiUb.',NULL,'',NULL,NULL,NULL,NULL,'','',NULL,NULL,0,1,'2018-03-29 14:16:11','2018-03-29 14:16:11'),(10,NULL,'sham','sham@avainfotech.com','$2y$10$inamtYNoeB9J5EmkDxGwd.cIxF2PBZircM4pyqS80XfODJYznEtUW','1522746258Koala.jpg','w4ety4yewry4e',NULL,NULL,NULL,NULL,'','',NULL,NULL,0,1,'2018-04-03 07:03:03','2018-04-03 13:19:51'),(11,'user','Rahul Sharma','rahulsharma@avainfotech.com',NULL,NULL,'#51',NULL,2,'60','3','09-04-2018','09-07-2018',NULL,NULL,0,1,'2018-04-09 12:03:45','2018-04-09 12:03:45'),(12,'guest','Gurpreet singh','rahulsharma1@avainfotech.com',NULL,NULL,'#52',NULL,2,'60','3','09-04-2018','09-07-2018',NULL,NULL,0,1,'2018-04-09 12:59:04','2018-04-09 12:59:04'),(13,'guest','Parveen Kumar','parveen@avainfotech.com',NULL,NULL,'asjfj;fs',NULL,NULL,NULL,NULL,'','',NULL,NULL,0,1,'2018-04-09 13:32:16','2018-04-09 13:32:16'),(14,'guest','Rahul Sharma','rahulsharma2@avainfotech.com',NULL,NULL,'#51',NULL,2,'60','3','12-04-2018','12-07-2018','B07C9CSJ3T,B07BR7ZPQD','cus_CfJFCWaxGI4mGJ',1,1,'2018-04-12 05:31:38','2018-04-12 05:31:38'),(15,'guest','Gurpreet singh','rahulsharma2@avainfoteech.com',NULL,NULL,'Plot no. 10',NULL,2,'60','3','12-04-2018','12-07-2018','','cus_CfKUYDPkFERgx8',0,1,'2018-04-12 07:26:26','2018-04-12 07:26:26');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'singhgur_fff'
--

--
-- Dumping routines for database 'singhgur_fff'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-21  0:14:58
